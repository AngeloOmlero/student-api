rootProject.name = "chat-application"
